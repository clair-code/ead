System-PHP-login-object-oriented
================================

Esse é um sistema simples de login usando o PHP orientado a objeto. 
Estou aberto a proposta de melhorias, algumas  já estão sendo implementadas.
Toda as explicações necessárias sobre este projeto, você encontrará no meu blog

www.devsguide.wordpress.com

This is a simple system login using PHP object-oriented. 
Feel free to propose increments, some improvements are been already implemented.
Explanations about this project, you will find in my blog. Access!

www.devsguide.wordpress.com
