<?php 
	require_once(dirname(__FILE__).'/class/Login.php');
	$objLogin = new Login();
	
	$objLogin->deslogar();
?>